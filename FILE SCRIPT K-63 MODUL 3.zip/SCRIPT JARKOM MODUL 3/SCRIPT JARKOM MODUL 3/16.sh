# BAGIAN 1: FIX IP GOJO (BENTROK dengan shoko 10.95.1.3)

# Jalankan di gojo:
ip addr del 10.95.1.3/24 dev eth0
ip addr add 10.95.1.4/24 dev eth0
ip route add default via 10.95.1.1

# Verifikasi
ip addr show eth0 | grep inet    # HARUS 10.95.1.4/24

# Konfigurasi permanen
cat > /etc/network/interfaces << 'ENDOFFILE'
auto eth0
iface eth0 inet static
    address 10.95.1.4
    netmask 255.255.255.0
    gateway 10.95.1.1
    dns-nameservers 192.168.122.1
ENDOFFILE

# BAGIAN 2: Install Nginx di Gojo

# Jalankan di gojo:
echo "nameserver 10.95.1.2" > /etc/resolv.conf
apt-get update
apt-get install -y nginx

# BAGIAN 3: FIX API WORKER - HANDLE /api YANG TIDAK BISA

# PRASYARAT: tanpa ini, request /api menghasilkan 404
# Jalankan di nanami, todo, DAN kirara:

cat > /etc/nginx/sites-available/api << 'ENDOFFILE'
server {
    listen 80;
    server_name api.jujutsu.k63.com;
    root /var/www/api;
    index index.php;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/run/php/php8.4-fpm.sock;
    }

    allow 10.95.4.2;
    deny all;
}
ENDOFFILE

nginx -t && service nginx restart

# BAGIAN 4: Konfigurasi Gojo - Path-Based Routing

# Jalankan di gojo:

cat > /etc/nginx/sites-available/gojo << 'ENDOFFILE'
upstream frontend_cluster {
    server 10.95.4.3;
    server 10.95.4.4;
}

server {
    listen 80;
    server_name jujutsu.k63.com www.jujutsu.k63.com;

    location / {
        proxy_pass http://frontend_cluster;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }

    location /api {
        proxy_pass http://10.95.4.2;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
ENDOFFILE

ln -sf /etc/nginx/sites-available/gojo /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t
service nginx restart

# BAGIAN 5: Restart Geto (upstream api_cluster sudah ada)

# Jalankan di geto (pastikan sudah terkonfigurasi Task 15):
service nginx restart

# BAGIAN 6: Verifikasi

# --- 6a. Dari gojo - cek Round Robin ---
for i in $(seq 1 10); do curl -s http://localhost/ | grep -o 'Hostname: [a-z]*'; done | sort | uniq -c

# Di gojo
for i in $(seq 1 100); do curl -s http://localhost/ | grep -o 'Hostname: [a-z]*'; done | sort | uniq -c

# --- 6b. Dari gojo - cek /api ---
curl http://localhost/api

# --- 6c. Dari client Divisi A/B ---
# Jalankan di zenin / okkotsu / kugisaki:
echo "nameserver 10.95.1.2" > /etc/resolv.conf
curl http://jujutsu.k63.com/
curl http://www.jujutsu.k63.com/
curl http://jujutsu.k63.com/api