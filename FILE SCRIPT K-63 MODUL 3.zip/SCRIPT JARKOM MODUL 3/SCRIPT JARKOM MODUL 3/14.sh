# Langkah 0: Fix IP Gojo 

# Jalankan di gojo:
ip addr del 10.95.1.3/24 dev eth0
ip addr add 10.95.1.4/24 dev eth0
ip route add default via 10.95.1.1
cat > /etc/network/interfaces << 'ENDOFFILE'
 auto eth0
 iface eth0 inet static
     address 10.95.1.4
     netmask 255.255.255.0
     gateway 10.95.1.1
     dns-nameservers 192.168.122.1
ENDOFFILE
ip addr show eth0 | grep inet    # harus 10.95.1.4/24

----------------------------------------------------------------------------------------------------------

# Langkah 1: Install Nginx + PHP-FPM (SEMUA WORKER)

# Jalankan di maki, panda, nanami, todo, kirara
echo "nameserver 10.95.1.2" > /etc/resolv.conf
apt-get update
apt-get install -y nginx php-fpm php-mysql

# Start php-fpm (binary di trixie = php-fpm8.4)
/usr/sbin/php-fpm8.4 -D

----------------------------------------------------------------------------------------------------------

# Langkah 2: API WORKER (nanami, todo, kirara)

# --- 2a. Buat direktori & file API ---
mkdir -p /var/www/api
cat > /var/www/api/index.php << 'ENDOFFILE'
<?php
header('Content-Type: application/json');

$servername = "10.95.4.9";
$username = "root";
$password = "root_password";
$dbname = "db_shibuya_k63";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(["error" => "Connection failed"]));
}

$client_ip = $_SERVER['REMOTE_ADDR'];
$endpoint = $_SERVER['REQUEST_URI'];

$stmt = $conn->prepare("INSERT INTO request_logs (client_ip, endpoint) VALUES (?, ?)");
$stmt->bind_param("ss", $client_ip, $endpoint);
$stmt->execute();
$stmt->close();

$result = $conn->query("SELECT * FROM request_logs ORDER BY id DESC LIMIT 5");
$logs = [];
while ($row = $result->fetch_assoc()) {
    $logs[] = $row;
}

$conn->close();

echo json_encode([
    "status" => "success",
    "hostname" => gethostname(),
    "client_ip" => $client_ip,
    "recent_logs" => $logs
]);
ENDOFFILE

# Validasi syntax
php -l /var/www/api/index.php

# --- 2b. Virtual Host API (HANYA dari geto 10.95.4.2) ---
cat > /etc/nginx/sites-available/api << 'ENDOFFILE'
server {
    listen 80;
    server_name api.jujutsu.k63.com;
    root /var/www/api;
    index index.php;

    location / {
        try_files $uri $uri/ =404;
    }

    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/run/php/php8.4-fpm.sock;
    }

    allow 10.95.4.2;
    deny all;
}
ENDOFFILE

ln -sf /etc/nginx/sites-available/api /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t
service nginx restart

----------------------------------------------------------------------------------------------------------

# Langkah 3: FRONTEND WORKER (maki, panda)

# --- 3a. Buat direktori & file PHP ---
mkdir -p /var/www/frontend
cat > /var/www/frontend/index.php << 'ENDOFFILE'
<?php
echo "<h1>Frontend Worker</h1>";
echo "<p>Hostname: " . gethostname() . "</p>";
ENDOFFILE

php -l /var/www/frontend/index.php

# --- 3b. Virtual Host Frontend (HANYA dari gojo 10.95.1.4) ---
cat > /etc/nginx/sites-available/frontend << 'ENDOFFILE'
server {
    listen 80;
    server_name jujutsu.k63.com www.jujutsu.k63.com;
    root /var/www/frontend;
    index index.php;

    location / {
        try_files $uri $uri/ =404;
    }

    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/run/php/php8.4-fpm.sock;
    }

    allow 10.95.1.4;
    deny all;
}
ENDOFFILE

ln -sf /etc/nginx/sites-available/frontend /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t
service nginx restart

----------------------------------------------------------------------------------------------------------

# Langkah 4: VERIFIKASI

# --- 4a. Akses langsung dari worker (HARUS 403) ---
curl http://localhost/
curl http://10.95.4.3/     # dari maki
curl http://10.95.4.5/     # dari nanami

# --- 4b. Akses via geto ke API worker (HARUS BERHASIL) ---
# Jalankan di geto:
curl http://10.95.4.5/     # nanami
curl http://10.95.4.6/     # todo
curl http://10.95.4.7/     # kirara

# --- 4c. Akses via gojo ke Frontend (HARUS BERHASIL) ---
# Jalankan di gojo (PASTIKAN IP gojo = 10.95.1.4):
curl http://10.95.4.3/     # maki
curl http://10.95.4.4/     # panda

# --- 4d. geto ke Frontend worker (HARUS 403 - tidak diizinkan) ---
# Jalankan di geto:
curl http://10.95.4.3/     # harus 403