# BAGIAN 1: FIX IP CLIENT (kalau belum dapat DHCP)

# --- Di ino (Network 3) ---
ip addr add 10.95.3.2/24 dev eth0
ip link set eth0 up
ip route add default via 10.95.3.1
echo "nameserver 10.95.1.2" > /etc/resolv.conf
ip addr show eth0 | grep inet    # HARUS 10.95.3.2/24

# --- Di zenin (Network 2) sudah DHCP, cek saja ---
ip addr show eth0 | grep inet    # HARUS 10.95.2.4

# BAGIAN 2: GOJO - Teruskan Header Client IP

# Jalankan di gojo:

cat > /etc/nginx/sites-available/gojo << 'ENDOFFILE'
upstream frontend_cluster {
    server 10.95.4.3;
    server 10.95.4.4;
}

server {
    listen 80;
    server_name jujutsu.k63.com www.jujutsu.k63.com;

    # Percayai informasi IP dari proxy terpercaya
    set_real_ip_from 10.95.0.0/16;
    set_real_ip_from 192.168.122.0/24;
    real_ip_header X-Forwarded-For;
    real_ip_recursive on;

    location / {
        proxy_pass http://frontend_cluster;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }

    location /api {
        proxy_pass http://10.95.4.2;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
ENDOFFILE

nginx -t && service nginx restart

# BAGIAN 3: GETO - Hanya Percayai Proxy Terpercaya (gojo)

# Jalankan di geto:

cat > /etc/nginx/sites-available/lb << 'ENDOFFILE'
upstream api_cluster {
    server 10.95.4.5 weight=3;
    server 10.95.4.6 weight=1;
}

server {
    listen 80;
    server_name geto.jujutsu.k63.com;

    # HANYA gojo yang dipercayai sebagai proxy
    set_real_ip_from 10.95.1.4;
    real_ip_header X-Forwarded-For;
    real_ip_recursive on;

    location / {
        proxy_pass http://api_cluster;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
ENDOFFILE

nginx -t && service nginx restart

# BAGIAN 4: API WORKER - Simpan IP Terverifikasi

# Jalankan di nanami, todo, DAN kirara:

cat > /var/www/api/index.php << 'ENDOFFILE'
<?php
header('Content-Type: application/json');

$servername = "10.95.4.9";
$username = "root";
$password = "root_password";
$dbname = "db_shibuya_k63";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(["error" => "Connection failed"]));
}

// Daftar proxy terpercaya - IP ini TIDAK boleh dianggap client
$trusted_proxy = array("10.95.4.2", "10.95.1.4");

$client_ip = $_SERVER['REMOTE_ADDR'];

// Ambil IP client asli dari X-Forwarded-For, lewati proxy terpercaya
if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $xff_list = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
    foreach ($xff_list as $ip) {
        $ip = trim($ip);
        if (filter_var($ip, FILTER_VALIDATE_IP) && !in_array($ip, $trusted_proxy)) {
            $client_ip = $ip;
            break;
        }
    }
}

$endpoint = $_SERVER['REQUEST_URI'];

$stmt = $conn->prepare("INSERT INTO request_logs (client_ip, endpoint) VALUES (?, ?)");
$stmt->bind_param("ss", $client_ip, $endpoint);
$stmt->execute();
$stmt->close();

$result = $conn->query("SELECT * FROM request_logs ORDER BY id DESC LIMIT 5");
$logs = [];
while ($row = $result->fetch_assoc()) {
    $logs[] = $row;
}

$conn->close();

echo json_encode([
    "status" => "success",
    "hostname" => gethostname(),
    "client_ip" => $client_ip,
    "recent_logs" => $logs
]);
ENDOFFILE

php -l /var/www/api/index.php

# Pastikan nginx config API sudah handle /api (Task 16)
cat > /etc/nginx/sites-available/api << 'ENDOFFILE'
server {
    listen 80;
    server_name api.jujutsu.k63.com;
    root /var/www/api;
    index index.php;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/run/php/php8.4-fpm.sock;
    }

    allow 10.95.4.2;
    deny all;
}
ENDOFFILE

nginx -t && service nginx restart

# BAGIAN 5: VERIFIKASI DARI CLIENT NETWORK 2 & 3

# --- Di zenin (Network 2) ---
echo "nameserver 10.95.1.2" > /etc/resolv.conf
curl http://jujutsu.k63.com/api
# HARUS: "client_ip":"10.95.2.4"

# --- Di ino (Network 3) ---
echo "nameserver 10.95.1.2" > /etc/resolv.conf
curl http://jujutsu.k63.com/api
# HARUS: "client_ip":"10.95.3.2"

# BAGIAN 6: CEK DATABASE di yaga

mysql -h 10.95.4.9 -u root -proot_password db_shibuya_k63 -e "SELECT * FROM request_logs ORDER BY id DESC LIMIT 10;"