# BAGIAN 1: Pastikan Kirara API Berjalan

# PRASYARAT: kirara sudah dikonfigurasi di Task 14
# Jalankan di kirara:

ip addr add 10.95.4.7/24 dev eth0 2>/dev/null
ip link set eth0 up
ip route add default via 10.95.4.1 2>/dev/null

# Cek status
ip addr show eth0 | grep inet
ps aux | grep nginx | head -2
ps aux | grep php-fpm | head -2
ls -la /run/php/php8.4-fpm.sock
ls -la /var/www/api/index.php

# Kalau php-fpm mati:
/usr/sbin/php-fpm8.4 -D
service nginx restart

# Cek config kirara sudah allow geto
grep -n "allow\|deny" /etc/nginx/sites-available/api

# BAGIAN 2: Konfigurasi Upstream di Geto - Backup + Health Check

# Jalankan di geto:

cat > /etc/nginx/sites-available/lb << 'ENDOFFILE'
upstream api_cluster {
    server 10.95.4.5 weight=3 max_fails=2 fail_timeout=5s;
    server 10.95.4.6 weight=1 max_fails=2 fail_timeout=5s;
    server 10.95.4.7 backup;
}

server {
    listen 80;
    server_name geto.jujutsu.k63.com;

    set_real_ip_from 10.95.1.4;
    real_ip_header X-Forwarded-For;
    real_ip_recursive on;

    location / {
        proxy_pass http://api_cluster;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
ENDOFFILE

nginx -t && service nginx restart

# BAGIAN 3: Baseline - Sebelum Gangguan

# Jalankan di geto:

# 3a. Test kirara langsung (hostname: kirara)
curl http://10.95.4.7/

# 3b. Distribusi normal (harus nanami + todo saja)
for i in $(seq 1 10); do curl -s http://localhost/ | grep -o '"hostname":"[^"]*"'; done | sort | uniq -c

# BAGIAN 4: Simulasi Gangguan

# Jalankan di nanami:
service nginx stop
ps aux | grep nginx | grep -v grep

# Jalankan di todo:
service nginx stop
ps aux | grep nginx | grep -v grep

# BAGIAN 5: Buktikan Failover ke Kirara

# Jalankan di geto - tunggu ~5 detik (fail_timeout) dulu:

sleep 5
curl http://localhost/
curl http://localhost/api

# Loop - semua harus kirara
for i in $(seq 1 10); do curl -s http://localhost/ | grep -o '"hostname":"[^"]*"'; done | sort | uniq -c

# --- Dari client (zenin / ino) ---
# Jalankan di zenin:
curl http://jujutsu.k63.com/api
for i in $(seq 1 10); do curl -s http://jujutsu.k63.com/api | grep -o '"hostname":"[^"]*"'; done | sort | uniq -c

# BAGIAN 6: Pulihkan Layanan

# Jalankan di nanami:
service nginx start

# Jalankan di todo:
service nginx start

# Jalankan di geto - harus kembali ke nanami/todo:
for i in $(seq 1 10); do curl -s http://localhost/ | grep -o '"hostname":"[^"]*"'; done | sort | uniq -c