# BAGIAN 1: Persiapan Kusakabe (Alpine)

# Jalankan di kusakabe:

# 1a. Set DNS ke utahime
echo "nameserver 10.95.1.2" > /etc/resolv.conf

# 1b. Cek IP address
ip addr show eth0 | grep inet
# HARUS: inet 10.95.3.3/24

# 1c. Kalau belum ada IP, set manual:
ip addr add 10.95.3.3/24 dev eth0
ip link set eth0 up
ip route add default via 10.95.3.1

# 1d. Install Apache Benchmark
apk update
apk add apache2-utils

# 1e. Verifikasi
ab -V
# Output: This is ApacheBench, Version 2.3

# BAGIAN 2: Benchmark Baseline - Halaman Web "/"

# Jalankan di kusakabe:
ab -n 600 -c 30 http://jujutsu.k63.com/

# BAGIAN 3: Benchmark dengan Rate Limiting Aktif - "/api"
# Jalankan di kusakabe:
ab -n 600 -c 30 http://jujutsu.k63.com/api

# BAGIAN 4: Benchmark via IP (Alternatif / Bukti Tambahan)
# Jalankan di kusakabe:
ab -n 600 -c 30 http://10.95.1.4/
ab -n 600 -c 30 http://10.95.1.4/api

# BAGIAN 5: Analisis Access Log Gojo
# Jalankan di gojo:

# 5a. Hitung response code dari benchmark terakhir
tail -1200 /var/log/nginx/access.log | awk '{print $9}' | sort | uniq -c | sort -rn

# 5b. Lihat request yang DITOLAK rate limit
grep " 429 " /var/log/nginx/access.log | tail -10

# 5c. Cek kegagalan APLIKASI (5xx)
grep -E " 5[0-9][0-9] " /var/log/nginx/access.log | tail -10

# 5d. Cek request ke "/" (harus semua 200)
grep "GET / HTTP" /var/log/nginx/access.log | tail -10 | awk '{print $9}' | sort | uniq -c

# 5e. Cek kegagalan koneksi di error log
tail -20 /var/log/nginx/error.log