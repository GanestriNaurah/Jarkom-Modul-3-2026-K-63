
# SEMUA PERINTAH DIJALANKAN DI GETO

# BAGIAN 1: Install Nginx + Curl

echo "nameserver 10.95.1.2" > /etc/resolv.conf
apt-get update
apt-get install -y nginx curl

# BAGIAN 2: Konfigurasi Upstream dan Virtual Host

cat > /etc/nginx/sites-available/lb << 'ENDOFFILE'
upstream api_cluster {
    server 10.95.4.5 weight=3;
    server 10.95.4.6 weight=1;
}

server {
    listen 80;
    server_name geto.jujutsu.k63.com;

    location / {
        proxy_pass http://api_cluster;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
ENDOFFILE

# BAGIAN 3: Aktifkan dan Restart

ln -sf /etc/nginx/sites-available/lb /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t
service nginx restart

# BAGIAN 4: Verifikasi Distribusi Beban

# 4a. Cek satu request berhasil
curl http://localhost/

# 4b. Loop 20 request - cek rasio
for i in $(seq 1 20); do curl -s http://localhost/ | grep -o '"hostname":"[^"]*"'; done | sort | uniq -c

# 4c. Loop 40 request - hasil lebih akurat
for i in $(seq 1 40); do curl -s http://localhost/ | grep -o '"hostname":"[^"]*"'; done | sort | uniq -c

# BAGIAN 5: Verifikasi Tambahan

# Cek nginx listening
ss -tlnp | grep :80

# Cek config upstream
nginx -T | grep -A5 upstream

# Cek akses dari node lain di Network 4
curl http://10.95.4.2/