# BAGIAN 1: Buat Direktori Cache

# Jalankan di gojo:

mkdir -p /var/cache/nginx/frontend
chown -R www-data:www-data /var/cache/nginx

# BAGIAN 2: Konfigurasi Gojo

# Jalankan di gojo:
# CATATAN: proxy_cache_path dan limit_req_zone HARUS di luar blok server{}

cat > /etc/nginx/sites-available/gojo << 'ENDOFFILE'
proxy_cache_path /var/cache/nginx/frontend levels=1:2 keys_zone=frontend_cache:10m max_size=1g inactive=60m;

limit_req_zone $binary_remote_addr zone=api_limit:10m rate=10r/s;

upstream frontend_cluster {
    server 10.95.4.3;
    server 10.95.4.4;
}

server {
    listen 80;
    server_name jujutsu.k63.com www.jujutsu.k63.com;

    set_real_ip_from 10.95.0.0/16;
    set_real_ip_from 192.168.122.0/24;
    real_ip_header X-Forwarded-For;
    real_ip_recursive on;

    # Halaman web frontend - DENGAN CACHING
    location / {
        proxy_cache frontend_cache;
        proxy_cache_valid 200 10m;
        proxy_cache_key "$scheme$request_method$host$request_uri";
        add_header X-Cache-Status $upstream_cache_status;
        proxy_pass http://frontend_cluster;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }

    # API - DENGAN RATE LIMITING
    location /api {
        limit_req zone=api_limit burst=5 nodelay;
        limit_req_status 429;
        proxy_pass http://10.95.4.2;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
ENDOFFILE

nginx -t && service nginx restart

# BAGIAN 3: Verifikasi Caching (MISS -> HIT)

# Clear cache dulu di gojo:

# Di gojo - hapus cache
rm -rf /var/cache/nginx/frontend/*

# Jalankan di client (zenin / ino / kusakabe):

echo "nameserver 10.95.1.2" > /etc/resolv.conf

curl -I http://jujutsu.k63.com/
curl -I http://jujutsu.k63.com/
curl -I http://jujutsu.k63.com/

# HARUS:
# Request 1 -> X-Cache-Status: MISS
# Request 2 -> X-Cache-Status: HIT
# Request 3 -> X-Cache-Status: HIT

# BAGIAN 4: Verifikasi Rate Limiting

# Jalankan di client (zenin):

for i in $(seq 1 50); do curl -s -o /dev/null -w "%{http_code} " http://jujutsu.k63.com/api; done; echo

# HARUS: muncul beberapa 200 lalu banyak 429

# BAGIAN 5: Utility - Cek & Clear Cache

# Jalankan di gojo:

# Cek isi cache
ls -la /var/cache/nginx/frontend/

# Cek ukuran cache
du -sh /var/cache/nginx/frontend/

# Clear cache (untuk test ulang MISS)
rm -rf /var/cache/nginx/frontend/*

# Cek log error rate limit
tail -20 /var/log/nginx/error.log