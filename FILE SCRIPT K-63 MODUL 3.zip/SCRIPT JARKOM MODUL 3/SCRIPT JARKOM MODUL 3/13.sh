# Langkah 1: Install MariaDB (Jalankan di yaga DAN inumaki)

echo "nameserver 192.168.122.1" > /etc/resolv.conf
apt-get update
apt-get install -y mariadb-server mariadb-client

----------------------------------------------------------------------------------------------------------

# Langkah 2: Konfigurasi yaga (Master) - 10.95.4.9

# Buat direktori log dan file index
mkdir -p /var/log/mysql
touch /var/log/mysql/mysql-bin.index
chown mysql:mysql /var/log/mysql
chown mysql:mysql /var/log/mysql/mysql-bin.index

# Edit konfigurasi MariaDB
cat > /etc/mysql/mariadb.conf.d/50-server.cnf << 'EOF'
[mysqld]
server-id = 1
log-bin = /var/log/mysql/mysql-bin.log
binlog_do_db = db_shibuya_k63
bind-address = 0.0.0.0
EOF

# Restart MariaDB
service mariadb restart

# Buat database dan tabel
mysql -u root << 'EOF'
CREATE DATABASE IF NOT EXISTS db_shibuya_k63;
USE db_shibuya_k63;
CREATE TABLE IF NOT EXISTS request_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    client_ip VARCHAR(45),
    endpoint VARCHAR(255),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
FLUSH PRIVILEGES;
EOF

# Buat user replication
mysql -u root << 'EOF'
CREATE USER IF NOT EXISTS 'repl'@'10.95.4.%' IDENTIFIED BY 'repl_password';
GRANT REPLICATION SLAVE ON *.* TO 'repl'@'10.95.4.%';
FLUSH PRIVILEGES;
EOF

# Grant remote access untuk Network 4
mysql -u root << 'EOF'
GRANT ALL PRIVILEGES ON *.* TO 'root'@'10.95.4.%' IDENTIFIED BY 'root_password';
FLUSH PRIVILEGES;
EOF

# Cek status master
mysql -u root -e "SHOW MASTER STATUS;"

----------------------------------------------------------------------------------------------------------

# Langkah 3: Konfigurasi inumaki (Slave) - 10.95.4.8

# Buat direktori log
mkdir -p /var/log/mysql
chown mysql:mysql /var/log/mysql

# Edit konfigurasi MariaDB
cat > /etc/mysql/mariadb.conf.d/50-server.cnf << 'EOF'
[mysqld]
server-id = 2
bind-address = 0.0.0.0
EOF

# Restart MariaDB
service mariadb restart

# Buat database dan tabel (untuk menghindari error replikasi)
mysql -u root << 'EOF'
CREATE DATABASE IF NOT EXISTS db_shibuya_k63;
USE db_shibuya_k63;
CREATE TABLE IF NOT EXISTS request_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    client_ip VARCHAR(45),
    endpoint VARCHAR(255),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
FLUSH PRIVILEGES;
EOF

# Hubungkan slave ke master
mysql -u root << 'EOF'
CHANGE MASTER TO
    MASTER_HOST='10.95.4.9',
    MASTER_USER='repl',
    MASTER_PASSWORD='repl_password',
    MASTER_LOG_FILE='mysql-bin.000001',
    MASTER_LOG_POS=940;
START SLAVE;
EOF

# Cek status slave
mysql -u root -e "SHOW SLAVE STATUS\G"

----------------------------------------------------------------------------------------------------------

# Langkah 4: Verifikasi Replikasi

# Di yaga (master) - masukkan data
mysql -u root db_shibuya_k63 -e "INSERT INTO request_logs (client_ip, endpoint) VALUES ('10.95.2.10', '/api/test-replication');"

# Di inumaki (slave) - cek data
mysql -u root db_shibuya_k63 -e "SELECT * FROM request_logs;"

----------------------------------------------------------------------------------------------------------

# Langkah 5: Verifikasi Remote Access dari Node Lain (Network 4)

# Install client di node lain (misal tengen, geto, worker)
echo "nameserver 192.168.122.1" > /etc/resolv.conf
apt-get update
apt-get install -y mariadb-client

# Query dari node lain
mysql -h 10.95.4.9 -u root -proot_password -e "SELECT * FROM db_shibuya_k63.request_logs;"