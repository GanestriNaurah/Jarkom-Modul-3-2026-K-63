# Langkah 1 — Update Zone File Forward (utahime)

cat > /etc/bind/db.jujutsu.k63.com << 'EOF'
$TTL 86400
@   IN  SOA  ns1.jujutsu.k63.com. admin.jujutsu.k63.com. (
        2024101503 ; Serial
        3600       ; Refresh
        1800       ; Retry
        604800     ; Expire
        86400 )    ; Minimum TTL

@       IN  NS   ns1.jujutsu.k63.com.
@       IN  NS   ns2.jujutsu.k63.com.

; A Record - Domain utama ke gojo
@       IN  A    10.95.1.4

; CNAME - www merujuk ke domain utama
www     IN  CNAME jujutsu.k63.com.

; A Record untuk ns1 dan ns2
ns1     IN  A    10.95.1.2
ns2     IN  A    10.95.1.3
EOF

----------------------------------------------------------------------------------------------------------

# Langkah 2 — Buat Reverse DNS Zone (PTR)

cat > /etc/bind/db.10.95.1 << 'EOF'
$TTL 86400
@   IN  SOA  ns1.jujutsu.k63.com. admin.jujutsu.k63.com. (
        2024101501 ; Serial
        3600       ; Refresh
        1800       ; Retry
        604800     ; Expire
        86400 )    ; Minimum TTL

@       IN  NS   ns1.jujutsu.k63.com.
@       IN  NS   ns2.jujutsu.k63.com.

; PTR Record - 10.95.1.4 → jujutsu.k63.com
4       IN  PTR  jujutsu.k63.com.
EOF

----------------------------------------------------------------------------------------------------------

# Langkah 3 — Update named.conf.local

cat > /etc/bind/named.conf.local << 'EOF'
zone "jujutsu.k63.com" {
    type master;
    file "/etc/bind/db.jujutsu.k63.com";
    allow-transfer { 10.95.1.3; };
    also-notify { 10.95.1.3; };
};

zone "1.95.10.in-addr.arpa" {
    type master;
    file "/etc/bind/db.10.95.1";
    allow-transfer { 10.95.1.3; };
    also-notify { 10.95.1.3; };
};
EOF

----------------------------------------------------------------------------------------------------------

# Langkah 4 — Aktifkan DNS Forwarder
cat > /etc/bind/named.conf.options << 'EOF'
options {
    directory "/var/cache/bind";
    forwarders {
        192.168.122.1;
    };
    recursion yes;
    allow-query { any; };
};
EOF

----------------------------------------------------------------------------------------------------------

# Langkah 5 — Validasi & Restart

named-checkconf
named-checkzone jujutsu.k63.com /etc/bind/db.jujutsu.k63.com
named-checkzone 1.95.10.in-addr.arpa /etc/bind/db.10.95.1
pkill named && sleep 1 && named -g &

----------------------------------------------------------------------------------------------------------

# Langkah 6 — Verifikasi dari Client

# Cek A record (domain → IP gojo)
dig @10.95.1.2 jujutsu.k63.com

# Cek CNAME (www → domain utama)
dig @10.95.1.2 www.jujutsu.k63.com

# Cek PTR (IP gojo → domain)
dig @10.95.1.2 -x 10.95.1.4

# Cek forwarder - ping domain internet
ping google.com