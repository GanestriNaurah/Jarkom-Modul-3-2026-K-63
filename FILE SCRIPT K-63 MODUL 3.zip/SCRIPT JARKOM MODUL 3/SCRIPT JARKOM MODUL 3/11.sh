# Langkah 1: Install BIND9
---------------------------
# Jalankan di utahime
echo "nameserver 192.168.122.1" > /etc/resolv.conf
apt-get update
apt-get install -y bind9 bind9utils dnsutils

----------------------------------------------------------------------------------------------------------

# Jalankan di shoko
echo "nameserver 192.168.122.1" > /etc/resolv.conf
apt-get update
apt-get install -y bind9 bind9utils dnsutils

----------------------------------------------------------------------------------------------------------

# Langkah 2: Konfigurasi Utahime (DNS Master)

# Buat zone file
cat > /etc/bind/db.jujutsu.k63.com << 'EOF'
$TTL 86400
@   IN  SOA  ns1.jujutsu.k63.com. admin.jujutsu.k63.com. (
        2024101501 ; Serial
        3600       ; Refresh
        1800       ; Retry
        604800     ; Expire
        86400 )    ; Minimum TTL

@       IN  NS   ns1.jujutsu.k63.com.
@       IN  NS   ns2.jujutsu.k63.com.

ns1     IN  A    10.95.1.2
ns2     IN  A    10.95.1.3
EOF

# Buat named.conf.local
cat > /etc/bind/named.conf.local << 'EOF'
zone "jujutsu.k63.com" {
    type master;
    file "/etc/bind/db.jujutsu.k63.com";
    allow-transfer { 10.95.1.3; };
    also-notify { 10.95.1.3; };
};
EOF

# Validasi
named-checkconf
named-checkzone jujutsu.k63.com /etc/bind/db.jujutsu.k63.com

# Start bind9
pkill named 2>/dev/null; sleep 1
named -g &

----------------------------------------------------------------------------------------------------------

# Langkah 3 — Konfigurasi Shoko (Slave)

cat > /etc/bind/named.conf.local << 'EOF'
zone "jujutsu.k63.com" {
    type slave;
    file "/etc/bind/db.jujutsu.k63.com";
    masters { 10.95.1.2; };
};
EOF

# Validasi
named-checkconf

# Start bind9
pkill named 2>/dev/null; sleep 1
named -g &

----------------------------------------------------------------------------------------------------------

# Langkah 4 — Verifikasi dari Client

dig @10.95.1.2 jujutsu.k63.com
dig @10.95.1.3 jujutsu.k63.com

----------------------------------------------------------------------------------------------------------

# Langkah 5: Buktikan Sinkronisasi Serial

# Di utahime (master) - naikkan serial:
sed -i 's/2024101501/2024101502/' /etc/bind/db.jujutsu.k63.com
pkill named && sleep 1 && named -g &

# Di shoko (slave) - cek serial berubah:
dig @10.95.1.3 jujutsu.k63.com SOA




