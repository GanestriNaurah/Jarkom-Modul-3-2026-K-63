#!/bin/bash
# Soal 2 - DHCP server di tengen (10.95.4.10)
# Pakai:  bash 2.sh jichi_cek   (pastikan NAT/forwarding jichi hidup)
#         bash 2.sh tengen      (install + konfigurasi + jalankan)
#         bash 2.sh debug       (dhcpd foreground untuk lihat log live)

jichi_cek() {
  sysctl net.ipv4.ip_forward
  iptables -t nat -L POSTROUTING -n -v
  /root/setup-jichi.sh
}

tengen() {
  echo "nameserver 192.168.122.1" > /etc/resolv.conf
  apt update
  apt install -y isc-dhcp-server nano

  cat > /etc/default/isc-dhcp-server <<'EOF'
INTERFACESv4="eth0"
EOF

  cat > /etc/dhcp/dhcpd.conf <<'EOF'
default-lease-time 600;
max-lease-time 7200;
authoritative;

# Network 4: subnet lokal tanpa pool dinamis
subnet 10.95.4.0 netmask 255.255.255.0 {
}

# Network 2
subnet 10.95.2.0 netmask 255.255.255.0 {
    range 10.95.2.100 10.95.2.200;
    option routers 10.95.2.1;
    option domain-name-servers 192.168.122.1;
}

# Network 3
subnet 10.95.3.0 netmask 255.255.255.0 {
    range 10.95.3.100 10.95.3.200;
    option routers 10.95.3.1;
    option domain-name-servers 192.168.122.1;
}
EOF

  # cadangan
  cp /etc/dhcp/dhcpd.conf /root/dhcpd.conf
  cp /etc/default/isc-dhcp-server /root/isc-dhcp-server.default
  cp /etc/network/interfaces /root/interfaces.bak

  # /root/setup-dhcp.sh
  cat > /root/setup-dhcp.sh <<'EOF'
#!/bin/bash

echo "nameserver 192.168.122.1" > /etc/resolv.conf
cp /root/dhcpd.conf /etc/dhcp/dhcpd.conf
cp /root/isc-dhcp-server.default /etc/default/isc-dhcp-server
touch /var/lib/dhcp/dhcpd.leases
service isc-dhcp-server restart
EOF
  chmod +x /root/setup-dhcp.sh

  ip -br addr
  cat /etc/dhcp/dhcpd.conf
  dhcpd -t -cf /etc/dhcp/dhcpd.conf
  service isc-dhcp-server restart
  ps aux | grep dhcpd
}

debug() {
  service isc-dhcp-server stop
  dhcpd -4 -d -cf /etc/dhcp/dhcpd.conf eth0
  # selesai: Ctrl+C lalu  service isc-dhcp-server restart
}

case "$1" in
  jichi_cek) jichi_cek ;;
  tengen)    tengen ;;
  debug)     debug ;;
  *) echo "Pakai: bash 2.sh jichi_cek | tengen | debug" ;;
esac
