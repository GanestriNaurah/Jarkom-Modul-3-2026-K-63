#!/bin/bash
# Soal 9 - Simulasi gangguan: relay mati -> client gagal -> relay dipulihkan
# Urutan:
#   1. jichi   : bash 9.sh matikan_relay
#   2. itadori : bash 9.sh client_gagal
#   3. jichi   : bash 9.sh pulihkan_relay
#   4. itadori : bash 9.sh client_pulih

matikan_relay() {
  service isc-dhcp-relay stop
  pkill dhcrelay
  ps aux | grep dhcrelay          # tidak boleh ada proses dhcrelay
}

client_gagal() {
  pkill udhcpc
  ip addr flush dev eth0
  udhcpc -i eth0
  # gejala: "broadcasting discover" berulang, lalu "udhcpc failed to get a DHCP lease"
  ip -br addr                     # eth0 tanpa IPv4
  ip route                        # kosong
}

pulihkan_relay() {
  service isc-dhcp-relay restart
  ps aux | grep dhcrelay
  # /usr/sbin/dhcrelay -q -i eth2 -i eth3 -i eth4 10.95.4.10
}

client_pulih() {
  pkill udhcpc
  ip addr flush dev eth0
  udhcpc -i eth0
  ip -br addr                     # 10.95.2.10/24 (Pool 1)
  ip route                        # default via 10.95.2.1
  cat /etc/resolv.conf            # search K63.com, nameserver 10.95.1.2 dan 10.95.1.3
}

# Penjelasan: DHCPDISCOVER adalah broadcast dan tidak bisa melewati router.
# Tanpa relay di jichi, paket berhenti di Network 2 dan tidak sampai ke tengen
# di Network 4. Setelah relay hidup, jichi meneruskan sebagai unicast ke 10.95.4.10.

case "$1" in
  matikan_relay) matikan_relay ;; client_gagal) client_gagal ;;
  pulihkan_relay) pulihkan_relay ;; client_pulih) client_pulih ;;
  *) echo "Pakai: bash 9.sh matikan_relay | client_gagal | pulihkan_relay | client_pulih" ;;
esac
