#!/bin/bash
# Soal 6 - Fixed address kugisaki (10.95.3.99)
# Pakai:  bash 6.sh mac       (di kugisaki; MAC 02:42:e2:07:ec:00)
#         bash 6.sh tengen
#         bash 6.sh client    (jalankan 2x, IP harus tetap 10.95.3.99)
#         bash 6.sh bukti     (di tengen)
#         bash 6.sh debug     (kalau kugisaki hanya "broadcasting discover")

mac() { ip link show eth0; }

tengen() {
  cat > /root/dhcpd.conf <<'EOF'
default-lease-time 600;
max-lease-time 7200;
authoritative;

class "pool1" {
  match if (substring(hardware, 1, 6) = 02:42:73:bc:7c:00) or
           (substring(hardware, 1, 6) = 02:42:d5:94:24:00);
}

class "pool2" {
  match if (substring(hardware, 1, 6) = 02:42:1c:8c:ac:00) or
           (substring(hardware, 1, 6) = 02:42:0c:6b:f2:00);
}

class "short" {
  match if (substring(hardware, 1, 6) = 02:42:16:ac:98:00) or
           (substring(hardware, 1, 6) = 02:42:91:bc:97:00);
}

class "long" {
  match if (substring(hardware, 1, 6) = 02:42:aa:db:27:00);
}

subnet 10.95.4.0 netmask 255.255.255.0 {
}

subnet 10.95.2.0 netmask 255.255.255.0 {
  option routers 10.95.2.1;
  option domain-name-servers 192.168.122.1;

  pool {
    allow members of "pool1";
    range 10.95.2.10 10.95.2.35;
  }

  pool {
    allow members of "pool2";
    range 10.95.2.70 10.95.2.95;
  }
}

subnet 10.95.3.0 netmask 255.255.255.0 {
  option routers 10.95.3.1;
  option domain-name-servers 10.95.1.2, 10.95.1.3;
  option domain-search "K63.com";

  pool {
    allow members of "short";
    range 10.95.3.10 10.95.3.89;
    default-lease-time 1800;
    max-lease-time 1800;
  }

  pool {
    allow members of "long";
    range 10.95.3.100 10.95.3.199;
    default-lease-time 43200;
    max-lease-time 43200;
  }

  host kugisaki {
    hardware ethernet 02:42:e2:07:ec:00;
    fixed-address 10.95.3.99;
  }
}
EOF
  # warning "Host declarations are global" aman
  dhcpd -t -cf /root/dhcpd.conf || exit 1
  cp /root/dhcpd.conf /etc/dhcp/dhcpd.conf
  service isc-dhcp-server restart
}

client() {
  ip addr flush dev eth0
  udhcpc -i eth0
  ip addr show eth0
  # hasil: lease of 10.95.3.99 obtained from 10.95.4.10, inet 10.95.3.99/24
}

bukti() {
  grep -B1 -A4 "host kugisaki" /etc/dhcp/dhcpd.conf
  # bukti .99 di luar semua pool dinamis
  grep -n "range" /etc/dhcp/dhcpd.conf
}

debug() {
  echo "# jichi: cek relay -> ps aux | grep dhcrelay"
  service isc-dhcp-server stop
  dhcpd -4 -d -cf /etc/dhcp/dhcpd.conf eth0
  # setelah selesai: Ctrl+C lalu  service isc-dhcp-server start
  # hasil log: DHCPDISCOVER, DHCPOFFER, DHCPREQUEST, DHCPACK on 10.95.3.99 via 10.95.3.1
}

case "$1" in
  mac) mac ;; tengen) tengen ;; client) client ;; bukti) bukti ;; debug) debug ;;
  *) echo "Pakai: bash 6.sh mac | tengen | client | bukti | debug" ;;
esac
