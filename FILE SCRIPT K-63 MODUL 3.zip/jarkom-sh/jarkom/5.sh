#!/bin/bash
# Soal 5 - Network 3: lease short (30 menit) dan long (12 jam), DNS, domain-search
# Pakai:  bash 5.sh mac | tengen | bersihkan_lease | client | leases
#
# MAC:
#   ino / kusakabe  02:42:16:ac:98:00 dan 02:42:91:bc:97:00
#   miwa            02:42:aa:db:27:00

mac() { ip link show eth0; }

tengen() {
  cat > /root/dhcpd.conf <<'EOF'
default-lease-time 600;
max-lease-time 7200;
authoritative;

class "pool1" {
  match if (substring(hardware, 1, 6) = 02:42:73:bc:7c:00) or
           (substring(hardware, 1, 6) = 02:42:d5:94:24:00);
}

class "pool2" {
  match if (substring(hardware, 1, 6) = 02:42:1c:8c:ac:00) or
           (substring(hardware, 1, 6) = 02:42:0c:6b:f2:00);
}

class "short" {
  match if (substring(hardware, 1, 6) = 02:42:16:ac:98:00) or
           (substring(hardware, 1, 6) = 02:42:91:bc:97:00);
}

class "long" {
  match if (substring(hardware, 1, 6) = 02:42:aa:db:27:00);
}

subnet 10.95.4.0 netmask 255.255.255.0 {
}

subnet 10.95.2.0 netmask 255.255.255.0 {
  option routers 10.95.2.1;
  option domain-name-servers 192.168.122.1;

  pool {
    allow members of "pool1";
    range 10.95.2.10 10.95.2.35;
  }

  pool {
    allow members of "pool2";
    range 10.95.2.70 10.95.2.95;
  }
}

subnet 10.95.3.0 netmask 255.255.255.0 {
  option routers 10.95.3.1;
  option domain-name-servers 10.95.1.2, 10.95.1.3;
  option domain-search "K63.com";

  pool {
    allow members of "short";
    range 10.95.3.10 10.95.3.89;
    default-lease-time 1800;
    max-lease-time 1800;
  }

  pool {
    allow members of "long";
    range 10.95.3.100 10.95.3.199;
    default-lease-time 43200;
    max-lease-time 43200;
  }
}
EOF
  dhcpd -t -cf /root/dhcpd.conf || exit 1
  cp /root/dhcpd.conf /etc/dhcp/dhcpd.conf
  service isc-dhcp-server restart
  ps aux | grep dhcpd
}

# kalau lease lama (600 detik) masih nyangkut
bersihkan_lease() {
  service isc-dhcp-server stop
  cp /var/lib/dhcp/dhcpd.leases /root/dhcpd.leases.bak
  > /var/lib/dhcp/dhcpd.leases
  service isc-dhcp-server start
}

# ino, kusakabe, miwa
client() {
  ip addr flush dev eth0
  udhcpc -i eth0
  ip addr show eth0
  cat /etc/resolv.conf
  # hasil: .3.10 dan .3.11 lease 30 menit, .3.100 (miwa) lease 12 jam
}

leases() { cat /var/lib/dhcp/dhcpd.leases; }   # tengen

case "$1" in
  mac) mac ;; tengen) tengen ;; bersihkan_lease) bersihkan_lease ;; client) client ;; leases) leases ;;
  *) echo "Pakai: bash 5.sh mac | tengen | bersihkan_lease | client | leases" ;;
esac
