#!/bin/bash
# Soal 8 - Packet capture DHCP di tengen saat satu client minta lease baru
# Urutan:
#   1. tengen : bash 8.sh install
#   2. tengen : bash 8.sh capture      (biarkan terbuka, terminal 1)
#   3. itadori: bash 8.sh client
#   4. tengen : setelah "lease obtained", Ctrl+C di terminal capture
#   5. tengen : bash 8.sh baca

install() {
  echo "nameserver 192.168.122.1" > /etc/resolv.conf
  apt update
  apt install -y tcpdump
}

capture() {
  rm -f /root/dhcp-capture.pcap
  tcpdump -i eth0 -n -vvv port 67 or port 68 -w /root/dhcp-capture.pcap
}

# client (itadori, Network 2)
client() {
  pkill udhcpc
  ip addr flush dev eth0
  udhcpc -i eth0
}

baca() {
  tcpdump -n -vvv -r /root/dhcp-capture.pcap | grep -E "DHCP-Message|Server-ID|Your-IP|Lease-Time|Gateway-IP"
  # hasil blok itadori:
  # Discover  Gateway-IP 10.95.2.1
  # Offer     Your-IP 10.95.2.10, Server-ID 10.95.4.10, Lease-Time 464, Gateway-IP 10.95.2.1
  # Request   Server-ID 10.95.4.10, Gateway-IP 10.95.2.1
  # ACK       Your-IP 10.95.2.10, Server-ID 10.95.4.10, Lease-Time 464, Gateway-IP 10.95.2.1
  #
  # server        : 10.95.4.10
  # alamat client : 10.95.2.10
  # lease time    : 464 detik (sisa lease lama, server masih mengingat lease sebelumnya)
  # giaddr        : 10.95.2.1 = IP eth2 jichi (interface yang menerima request Network 2)
  #
  # Baris "Gateway-IP 10.95.4.1" dan NACK pada capture berasal dari renew client lain
  # yang ikut tertangkap, bukan dari itadori.
}

case "$1" in
  install) install ;; capture) capture ;; client) client ;; baca) baca ;;
  *) echo "Pakai: bash 8.sh install | capture | client | baca" ;;
esac
