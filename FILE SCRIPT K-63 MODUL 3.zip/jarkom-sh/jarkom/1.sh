#!/bin/bash
# Soal 1 - jichi (router/NAT) dan konfigurasi IP host
# Pakai:  bash 1.sh jichi
#         bash 1.sh host <N> <H>      contoh: bash 1.sh host 2 10  -> 10.95.2.10

jichi() {
  echo "nameserver 192.168.122.1" > /etc/resolv.conf
  apt update
  apt install -y iptables nano

  cat > /etc/network/interfaces <<'EOF'
auto eth0
iface eth0 inet dhcp
    post-up sysctl -w net.ipv4.ip_forward=1
    post-up iptables -t nat -C POSTROUTING -o eth0 -j MASQUERADE 2>/dev/null || iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE

auto eth1
iface eth1 inet static
    address 10.95.1.1
    netmask 255.255.255.0

auto eth2
iface eth2 inet static
    address 10.95.2.1
    netmask 255.255.255.0

auto eth3
iface eth3 inet static
    address 10.95.3.1
    netmask 255.255.255.0

auto eth4
iface eth4 inet static
    address 10.95.4.1
    netmask 255.255.255.0
EOF

  # /root/setup-jichi.sh (aman dijalankan berulang)
  cat > /root/setup-jichi.sh <<'EOF'
#!/bin/bash
PREFIX="10.95"

echo "nameserver 192.168.122.1" > /etc/resolv.conf

ip link set eth0 up
for i in 1 2 3 4; do
  ip addr replace $PREFIX.$i.1/24 dev eth$i
  ip link set eth$i up
done

sysctl -w net.ipv4.ip_forward=1
echo 'net.ipv4.ip_forward=1' > /etc/sysctl.d/99-forward.conf

iptables -t nat -F POSTROUTING
iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE
EOF
  chmod +x /root/setup-jichi.sh
  /root/setup-jichi.sh

  # bukti jichi
  ip -br addr
  sysctl net.ipv4.ip_forward
  iptables -t nat -L POSTROUTING -n -v      # harus satu baris MASQUERADE
  ping -c 3 8.8.8.8
  ping -c 3 google.com
}

host() {
  local N="$1" H="$2"
  [ -z "$N" ] || [ -z "$H" ] && { echo "Pakai: bash 1.sh host <N> <H>"; exit 1; }

  cat > /etc/network/interfaces <<EOF
auto eth0
iface eth0 inet static
    address 10.95.$N.$H
    netmask 255.255.255.0
    gateway 10.95.$N.1
    dns-nameservers 192.168.122.1
EOF
  echo "nameserver 192.168.122.1" > /etc/resolv.conf
  ifdown eth0; ifup eth0

  # bukti tiap host
  ip -br addr
  ip route
  ping -c 3 10.95.$N.1     # gateway
  ping -c 3 8.8.8.8        # akses eksternal (host yang relevan)
  ping -c 3 google.com
}

case "$1" in
  jichi) jichi ;;
  host)  host "$2" "$3" ;;
  *) echo "Pakai: bash 1.sh jichi | bash 1.sh host <N> <H>" ;;
esac
