#!/bin/bash
# Soal 10 - Autostart DHCP server (tengen) dan relay (jichi) saat boot
# Pakai:  bash 10.sh tengen | jichi | cek_tengen | cek_jichi | client | leases
# Setelah tengen dan jichi diset: restart jichi dulu, lalu tengen dari GNS3
# (stop lalu start). Jangan jalankan perintah manual, lalu jalankan cek_*.

tengen() {
  # node tanpa systemd, pakai update-rc.d
  cat /etc/default/isc-dhcp-server | grep INTERFACES      # harus INTERFACESv4="eth0"
  cp /root/dhcpd.conf /etc/dhcp/dhcpd.conf
  dhcpd -t -cf /etc/dhcp/dhcpd.conf || exit 1
  update-rc.d isc-dhcp-server enable
  ls /etc/rc2.d | grep -i dhcp
  cp /etc/dhcp/dhcpd.conf /root/dhcpd.conf.final

  # cadangan kalau update-rc.d tidak menaikkan dhcpd (di blok iface eth0)
  grep -q "service isc-dhcp-server restart" /etc/network/interfaces || \
    sed -i '/^iface eth0 inet/a\    post-up touch /var/lib/dhcp/dhcpd.leases\n    post-up service isc-dhcp-server restart' /etc/network/interfaces
  grep post-up /etc/network/interfaces
}

jichi() {
  cat > /etc/default/isc-dhcp-relay <<'EOF'
SERVERS="10.95.4.10"
INTERFACES="eth2 eth3 eth4"
OPTIONS=""
EOF
  cat /etc/default/isc-dhcp-relay
  update-rc.d isc-dhcp-relay enable
  ls /etc/rc2.d | grep -i dhcp

  # cadangan relay di blok iface eth4 (forwarding + NAT di eth0 sudah ada dari soal 1)
  grep -q "service isc-dhcp-relay restart" /etc/network/interfaces || \
    sed -i '/^iface eth4 inet/a\    post-up service isc-dhcp-relay restart' /etc/network/interfaces
  grep post-up /etc/network/interfaces
}

cek_tengen() {
  service isc-dhcp-server status
  ps aux | grep dhcpd
  ip addr show eth0
  ip route
  # hasil: /usr/sbin/dhcpd -4 -q -cf /etc/dhcp/dhcpd.conf eth0  (jam START harus baru)
}

cek_jichi() {
  service isc-dhcp-relay status
  ps aux | grep dhcrelay
  sysctl net.ipv4.ip_forward
  iptables -t nat -L POSTROUTING -n -v      # satu baris MASQUERADE
  ip addr
  # hasil: /usr/sbin/dhcrelay -q -i eth2 -i eth3 -i eth4 10.95.4.10  (jam START harus baru)
}

# semua client
client() {
  pkill udhcpc
  ip addr flush dev eth0
  udhcpc -i eth0
  ip addr show eth0
  ip route
  cat /etc/resolv.conf
  ping -c 3 10.95.2.1     # client Network 2
  ping -c 3 10.95.3.1     # client Network 3
}

leases() {
  cat /var/lib/dhcp/dhcpd.leases
  awk '/^lease/{ip=$2} /hardware ethernet/{gsub(";","",$3); print ip, $3}' /var/lib/dhcp/dhcpd.leases | sort -u
}

# /etc/dhcp/dhcpd.conf final = isi dari 7.sh (sudah termasuk perubahan soal 7)

case "$1" in
  tengen) tengen ;; jichi) jichi ;; cek_tengen) cek_tengen ;; cek_jichi) cek_jichi ;;
  client) client ;; leases) leases ;;
  *) echo "Pakai: bash 10.sh tengen | jichi | cek_tengen | cek_jichi | client | leases" ;;
esac
