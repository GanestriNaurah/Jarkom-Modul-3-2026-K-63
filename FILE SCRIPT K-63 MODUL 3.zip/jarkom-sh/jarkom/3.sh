#!/bin/bash
# Soal 3 - DHCP relay di jichi, jalankan server, client dapat lease
# Pakai:  bash 3.sh jichi | tengen | client

jichi() {
  apt update
  DEBIAN_FRONTEND=noninteractive apt install isc-dhcp-relay -y
  service isc-dhcp-relay restart
  ps aux | grep dhcrelay
  cat /etc/default/isc-dhcp-relay
}

tengen() {
  chmod +x /root/setup-dhcp.sh
  /root/setup-dhcp.sh
  service isc-dhcp-server stop
  /etc/init.d/isc-dhcp-server restart
  cat /var/lib/dhcp/dhcpd.leases
}

# client Alpine. Sebelum ini, edit /etc/network/interfaces client jadi dhcp
# (iface eth0 inet dhcp) dengan: nano /etc/network/interfaces
client() {
  echo "nameserver 192.168.122.1" > /etc/resolv.conf
  apk update
  ip addr flush dev eth0
  udhcpc -i eth0
  ip route
}

case "$1" in
  jichi)  jichi ;;
  tengen) tengen ;;
  client) client ;;
  *) echo "Pakai: bash 3.sh jichi | tengen | client" ;;
esac
