#!/bin/bash
# Soal 4 - Network 2: Pool 1 dan Pool 2 berdasarkan MAC
# Pakai:  bash 4.sh mac      (di client, untuk lihat MAC)
#         bash 4.sh tengen
#         bash 4.sh jichi
#         bash 4.sh client
#
# MAC:
#   itadori   02:42:73:bc:7c:00
#   fushiguro 02:42:d5:94:24:00
#   zenin     02:42:1c:8c:ac:00
#   okkotsu   02:42:0c:6b:f2:00

mac() { ip link show eth0; }

tengen() {
  cat > /root/dhcpd.conf <<'EOF'
default-lease-time 600;
max-lease-time 7200;
authoritative;

class "pool1" {
  match if (substring(hardware, 1, 6) = 02:42:73:bc:7c:00) or
           (substring(hardware, 1, 6) = 02:42:d5:94:24:00);
}

class "pool2" {
  match if (substring(hardware, 1, 6) = 02:42:1c:8c:ac:00) or
           (substring(hardware, 1, 6) = 02:42:0c:6b:f2:00);
}

subnet 10.95.4.0 netmask 255.255.255.0 {
}

# Network 2 (range lama .100-.200 dihapus supaya tidak tumpang tindih)
subnet 10.95.2.0 netmask 255.255.255.0 {
  option routers 10.95.2.1;
  option domain-name-servers 192.168.122.1;

  pool {
    allow members of "pool1";
    range 10.95.2.10 10.95.2.35;
  }

  pool {
    allow members of "pool2";
    range 10.95.2.70 10.95.2.95;
  }
}

# Network 3 (diganti di soal 5)
subnet 10.95.3.0 netmask 255.255.255.0 {
  range 10.95.3.100 10.95.3.200;
  option routers 10.95.3.1;
  option domain-name-servers 192.168.122.1;
}
EOF
  dhcpd -t -cf /root/dhcpd.conf || exit 1
  cp /root/dhcpd.conf /etc/dhcp/dhcpd.conf
  service isc-dhcp-server restart
  ps aux | grep dhcpd
}

# relay harus jalan (kalau log jichi "Dropping reply received on eth4")
jichi() {
  ps aux | grep dhcrelay
  pkill dhcrelay
  dhcrelay -4 -i eth2 -i eth3 -i eth4 10.95.4.10
}

client() {
  ip addr flush dev eth0
  udhcpc -i eth0
  ip addr show eth0
  # hasil: itadori 10.95.2.10, fushiguro 10.95.2.11, okkotsu 10.95.2.70, zenin 10.95.2.71
}

leases() { cat /var/lib/dhcp/dhcpd.leases; }   # jalankan di tengen

case "$1" in
  mac) mac ;; tengen) tengen ;; jichi) jichi ;; client) client ;; leases) leases ;;
  *) echo "Pakai: bash 4.sh mac | tengen | jichi | client | leases" ;;
esac
