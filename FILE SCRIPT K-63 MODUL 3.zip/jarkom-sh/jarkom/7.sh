#!/bin/bash
# Soal 7 - Opsi jaringan lengkap (mask, gateway, broadcast, DNS, domain)
# Client Alpine (udhcpc BusyBox) hanya menulis baris "search" dari opsi domain-name,
# jadi domain-name ditambahkan di samping domain-search.
# Pakai:  bash 7.sh tengen | client | cek_lease

tengen() {
  cat > /root/dhcpd.conf <<'EOF'
default-lease-time 600;
max-lease-time 7200;
authoritative;

class "pool1" {
  match if (substring(hardware, 1, 6) = 02:42:73:bc:7c:00) or
           (substring(hardware, 1, 6) = 02:42:d5:94:24:00);
}

class "pool2" {
  match if (substring(hardware, 1, 6) = 02:42:1c:8c:ac:00) or
           (substring(hardware, 1, 6) = 02:42:0c:6b:f2:00);
}

class "short" {
  match if (substring(hardware, 1, 6) = 02:42:16:ac:98:00) or
           (substring(hardware, 1, 6) = 02:42:91:bc:97:00);
}

class "long" {
  match if (substring(hardware, 1, 6) = 02:42:aa:db:27:00);
}

subnet 10.95.4.0 netmask 255.255.255.0 {
}

subnet 10.95.2.0 netmask 255.255.255.0 {
  option subnet-mask 255.255.255.0;
  option routers 10.95.2.1;
  option broadcast-address 10.95.2.255;
  option domain-name-servers 10.95.1.2, 10.95.1.3;
  option domain-name "K63.com";
  option domain-search "K63.com";

  pool {
    allow members of "pool1";
    range 10.95.2.10 10.95.2.35;
  }

  pool {
    allow members of "pool2";
    range 10.95.2.70 10.95.2.95;
  }
}

subnet 10.95.3.0 netmask 255.255.255.0 {
  option subnet-mask 255.255.255.0;
  option routers 10.95.3.1;
  option broadcast-address 10.95.3.255;
  option domain-name-servers 10.95.1.2, 10.95.1.3;
  option domain-name "K63.com";
  option domain-search "K63.com";

  pool {
    allow members of "short";
    range 10.95.3.10 10.95.3.89;
    default-lease-time 1800;
    max-lease-time 1800;
  }

  pool {
    allow members of "long";
    range 10.95.3.100 10.95.3.199;
    default-lease-time 43200;
    max-lease-time 43200;
  }

  host kugisaki {
    hardware ethernet 02:42:e2:07:ec:00;
    fixed-address 10.95.3.99;
  }
}
EOF
  dhcpd -t -cf /root/dhcpd.conf || exit 1
  cp /root/dhcpd.conf /etc/dhcp/dhcpd.conf
  service isc-dhcp-server restart
  ps aux | grep dhcpd
  grep -n "domain\|routers\|broadcast" /etc/dhcp/dhcpd.conf
}

# semua client (itadori, fushiguro, zenin, okkotsu, ino, kusakabe, miwa, kugisaki)
client() {
  pkill udhcpc
  ip addr flush dev eth0
  udhcpc -i eth0
  ip addr show eth0          # IP /24 dan brd 10.95.2.255 atau 10.95.3.255
  ip route                   # default via 10.95.2.1 atau 10.95.3.1
  cat /etc/resolv.conf       # search K63.com, nameserver 10.95.1.2 dan 10.95.1.3
}

# tengen: cocokkan lease dengan client (tanpa duplikat)
cek_lease() {
  grep -E "^lease|hardware ethernet|binding state" /var/lib/dhcp/dhcpd.leases
  awk '/^lease/{ip=$2} /hardware ethernet/{gsub(";","",$3); print ip, $3}' /var/lib/dhcp/dhcpd.leases | sort -u
  # hasil (7 pasang, kugisaki tidak muncul karena host reservation):
  # 10.95.2.10  02:42:73:bc:7c:00   itadori
  # 10.95.2.11  02:42:d5:94:24:00   fushiguro
  # 10.95.2.70  02:42:0c:6b:f2:00   okkotsu
  # 10.95.2.71  02:42:1c:8c:ac:00   zenin
  # 10.95.3.10  02:42:16:ac:98:00   ino / kusakabe
  # 10.95.3.11  02:42:91:bc:97:00   kusakabe / ino
  # 10.95.3.100 02:42:aa:db:27:00   miwa
}

case "$1" in
  tengen) tengen ;; client) client ;; cek_lease) cek_lease ;;
  *) echo "Pakai: bash 7.sh tengen | client | cek_lease" ;;
esac
